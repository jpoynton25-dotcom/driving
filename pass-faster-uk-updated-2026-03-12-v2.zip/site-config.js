window.PFUK_CONFIG = {
  siteUrl: 'https://passfasteruk.co.uk',
  contactEmail: 'hello@passfasteruk.co.uk',
  contactPhone: '+442000000000',
  contactPhoneDisplay: '+44 20 0000 0000',
  formEndpoint: 'https://formsubmit.co/hello@passfasteruk.co.uk',
  ga4Id: '',
  checkoutLinks: {
    starter: '',
    pro: ''
  }
};
